<html>
<head>
    <meta name ="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<style>


</style>

</head>
<body>


<?php include('Header.php');?>
<div class="container-fluid">

<div class="row" id="slide" >
<image src="image/date.jpg" style="height:500px;width:100%;" />

</div>

<!--End Of slider-->

<palign="center"><image src="image/heart.png" style="height:50px; width:8%;"> </p>
<h1 class="text-dark mt-2" style="font-family:Bookman Old Style Solid;"><i class="text-danger"><b><i>WELCOME TO DATE MATES<b><i></i></h1>
 <image src="image/heart.png" style="height:50px; width:8%;"> </p>

<div class="row ">
<div class="col-sm-2 my-5">
<div class="card">
<img class="img-fluid" src="image/girl1.jfif" class="card-img-top" style="height:200px;width:100%;" />
<div class="card-body text-center">
<h4 class="card-title text-danger" style="font-weight:bold;">Shandhya Verma</h4>
<h6>Girl <span class="text-secondary"><b>22 yr</b></span></h6>
<a href="#" class="btn btn-primary">Date <spn class="fa fa-heart"></span></a>
</div>
</div>
</div>


<div class="col-sm-2 my-5">
<div class="card">
<img class="img-fluid" src="image/girl4.jfif" class="card-img-top" style="height:200px;width:100%;" />
<div class="card-body text-center">
<h4 class="card-title text-danger" style="font-weight:bold;">Shreya Singh</h4>
<h6>Girl, <span class="text-secondary"><b>19 years</b></span></h6>
<a href="#" class="btn btn-primary">Date <spn class="fa fa-heart"></span></a>
</div>
</div>
</div>

<div class="col-sm-2 my-5">
<div class="card">
<img class="img-fluid" src="image/boy2.jfif" class="card-img-top" style="height:200px;width:100%;" />
<div class="card-body text-center">
<h4 class="card-title text-danger" style="font-weight:bold;">Sarvesh Rajput</h4>
<h6>Boy, <span class="text-secondary"><b>20 years</b></span></h6>
<a href="#" class="btn btn-primary">Date <span class="fa fa-heart"></span></a>
</div>
</div>
</div>


<div class="col-sm-2 my-5">
<div class="card">
<img class="img-fluid" src="image/boy6.jfif" class="card-img-top" style="height:200px;width:100%;" />
<div class="card-body text-center">
<h4 class="card-title text-danger" style="font-weight:bold;">Sandeep Rawat</h4>
<h6>Boy, <span class="text-secondary"><b>23 years</b></span></h6>
<a href="#" class="btn btn-primary">Date <span class="fa fa-heart"></span></a>
</div>
</div>
</div>


<div class="col-sm-2 my-5">
<div class="card">
<img class="img-fluid" src="image/girl8.jfif" class="card-img-top" style="height:200px;width:100%;" />
<div class="card-body text-center">
<h4 class="card-title text-danger" style="font-weight:bold;">Khushi Shrivastav</h4>
<h6>Girl, <span class="text-secondary"><b>24 years</b></span></h6>
<a href="#" class="btn btn-primary">Date <spn class="fa fa-heart"></span></a>
</div>
</div>
</div>


<div class="col-sm-2 my-5">
<div class="card">
<img class="img-fluid" src="image/boy9.jfif" class="card-img-top" style="height:200px;width:100%;" />
<div class="card-body text-center">
<h4 class="card-title text-danger" style="font-weight:bold;">Vivek Gupta</h4>
<h6>Boy, <span class="text-secondary"><b>20 years</b></span></h6>
<a href="#" class="btn btn-primary">Date <spn class="fa fa-heart"></span></a>
</div>
</div>
</div>


<div class="col-sm-2 my-5">
<div class="card">
<img class="img-fluid" src="image/boy7.jfif" class="card-img-top" style="height:200px;width:100%;" />
<div class="card-body text-center">
<h4 class="card-title text-danger" style="font-weight:bold;">Shashwat Singh</h4>
<h6>Boy, <span class="text-secondary"><b>22 years</b></span></h6>
<a href="#" class="btn btn-primary">Date <spn class="fa fa-heart"></span></a>
</div>
</div>
</div>


<div class="col-sm-2 my-5">
<div class="card">
<img class="img-fluid" src="image/boy3.jfif" class="card-img-top" style="height:200px;width:100%;" />
<div class="card-body text-center">
<h4 class="card-title text-danger" style="font-weight:bold;">Amit Singhal</h4>
<h6>Men, <span class="text-secondary"><b>32 years</b></span></h6>
<a href="#" class="btn btn-primary">Date <spn class="fa fa-heart"></span></a>
</div>
</div>
</div>


<div class="col-sm-2 my-5">
<div class="card">
<img class="img-fluid" src="image/girl4.jfif" class="card-img-top" style="height:200px;width:100%;" />
<div class="card-body text-center">
<h4 class="card-title text-danger" style="font-weight:bold;">Ishita Mehra</h4>
<h6>Women, <span class="text-secondary"><b>35 years</b></span></h6>
<a href="#" class="btn btn-primary">Date <spn class="fa fa-heart"></span></a>
</div>
</div>
</div>


<div class="col-sm-2 my-5">
<div class="card">
<img class="img-fluid" src="image/girl5.jfif" class="card-img-top" style="height:200px;width:100%;" />
<div class="card-body text-center">
<h4 class="card-title text-danger" style="font-weight:bold;">Shruti Sharma</h4>
<h6>Girl, <span class="text-secondary"><b>26 years</b></span></h6>
<a href="#" class="btn btn-primary">Date <spn class="fa fa-heart"></span></a>
</div>
</div>
</div>


<div class="col-sm-2 my-5">
<div class="card">
<img class="img-fluid" src="image/boy4.jfif" class="card-img-top" style="height:200px;width:100%;" />
<div class="card-body text-center">
<h4 class="card-title text-danger" style="font-weight:bold;">Shivang Shukla</h4>
<h6>Boy, <span class="text-secondary"><b>28 years</b></span></h6>
<a href="#" class="btn btn-primary">Date <spn class="fa fa-heart"></span></a>
</div>
</div>
</div>


<div class="col-sm-2 my-5">
<div class="card">
<img class="img-fluid" src="image/girl15.jfif" class="card-img-top" style="height:200px;width:100%;" />
<div class="card-body text-center">
<h4 class="card-title text-danger" style="font-weight:bold;">Naira Jindal</h4>
<h6>Women, <span class="text-secondary"><b>37 years</b></span></h6>
<a href="#" class="btn btn-primary">Date <spn class="fa fa-heart"></span></a>
</div>
</div>
</div>


<div class="col-sm-2 my-5">
<div class="card">
<img class="img-fluid" src="image/girl9.jfif" class="card-img-top" style="height:200px;width:100%;" />
<div class="card-body text-center">
<h4 class="card-title text-danger" style="font-weight:bold;">Subasha lodhi</h4>
<h6>Women, <span class="text-secondary"><b>40 years</b></span></h6>
<a href="#" class="btn btn-primary">Date <spn class="fa fa-heart"></span></a>
</div>
</div>
</div>


<div class="col-sm-2 my-5">
<div class="card">
<img class="img-fluid" src="image/boy16.jfif" class="card-img-top" style="height:200px;width:100%;" />
<div class="card-body text-center">
<h4 class="card-title text-danger" style="font-weight:bold;">Vaibhav Gupta</h4>
<h6>Men, <span class="text-secondary"><b>36 years</b></span></h6>
<a href="#" class="btn btn-primary">Date <spn class="fa fa-heart"></span></a>
</div>
</div>
</div>


<div class="col-sm-2 my-5">
<div class="card">
<img class="img-fluid" src="image/girl13.jfif" class="card-img-top" style="height:200px;width:100%;" />
<div class="card-body text-center">
<h4 class="card-title text-danger" style="font-weight:bold;">Isha Agarwal</h4>
<h6>Girl, <span class="text-secondary"><b>28 years</b></span></h6>
<a href="#" class="btn btn-primary">Date <spn class="fa fa-heart"></span></a>
</div>
</div>
</div>


<div class="col-sm-2 my-5">
<div class="card">
<img class="img-fluid" src="image/boy13.jfif" class="card-img-top" style="height:200px;width:100%;" />
<div class="card-body text-center">
<h4 class="card-title text-danger" style="font-weight:bold;">Mohit bhatt</h4>
<h6>Men, <span class="text-secondary"><b>42 years</b></span></h6>
<a href="#" class="btn btn-primary">Date <spn class="fa fa-heart"></span></a>
</div>
</div>
</div>


<div class="col-sm-2 my-5">
<div class="card">
<img class="img-fluid" src="image/boy12.jfif" class="card-img-top" style="height:200px;width:100%;" />
<div class="card-body text-center">
<h4 class="card-title text-danger" style="font-weight:bold;">Naman Maddesiya</h4>
<h6>Boy, <span class="text-secondary"><b>24 years</b></span></h6>
<a href="#" class="btn btn-primary">Date <spn class="fa fa-heart"></span></a>
</div>
</div>
</div>


<div class="col-sm-2 my-5">
<div class="card">
<img class="img-fluid" src="image/boy11.jfif" class="card-img-top" style="height:200px;width:100%;" />
<div class="card-body text-center">
<h4 class="card-title text-danger" style="font-weight:bold;">Aman Maurya</h4>
<h6>Boy, <span class="text-secondary"><b>21 years</b></span></h6>
<a href="#" class="btn btn-primary">Date <spn class="fa fa-heart"></span></a>
</div>
</div>
</div>




</div>




</div>

<!--Product card End -->

</div>

<?php include('footer.php');?>

</div>


</body>
</html>