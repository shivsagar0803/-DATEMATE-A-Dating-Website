<html>
<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">


</head>
<body>
<div class="container-fluid">
<div class="row">
<div class="col-sm-1 bg-dark"></div>
<div class="col-sm-3  bg-dark">
<h5 class="text-secondary  my-3">Online website</h5>
<img src="image/Datemates.png" class="my-3" style="heigth:40;width:60%;"/><br><br>
<p class="text-secondary"><p><b>Date mates is online website that helps anyone to find their mates and date with them virtually across the world </b></p></p><br>
</div>


<div class="col-sm-2 text-justify bg-dark">
<h5 class="text-secondary my-3">Gender-Type</h5>
<li Class="text-secondary">Men</li>
<li Class="text-secondary">Women</li>
<li Class="text-secondary">Teen</li>
<li Class="text-secondary">Boy</li>
<li Class="text-secondary">Girl</li>
<li Class="text-secondary">Gay</li>
<li Class="text-secondary">Lesbian</li>
</div>

<div class="col-sm-3 bg-dark ">
<h5 class="text-secondary  my-3 ">Useful Links</h5>
<p class="text-secondary">www.engineeringofficials.com</p>
<p class="text-secondary">www.codeslover.in</p>
<a href="https://www.facebook.com/codesslover"><i class="fa fa-facebook fa-lg text-white"style="height:50px;width:50px;border-radius:50%;padding-left:20px;
padding-top:20px;background-color:#1729af; "></i></a>
<a href="#"><i class="fa fa-google-plus bg-danger fa-lg text-white"style="height:50px;width:50px;border-radius:50%;padding-left:15px;
padding-top:20px; "></i></a>
<a href="https://www.twitter.com/codes_lover"><i class="fa fa-twitter fa-lg bg-info text-white"style="height:50px;width:50px;border-radius:50%;padding-left:15px;
padding-top:20px; "></i></a>
<a href="https://wa.me://91-9555761964"><i class="fa fa-whatsapp fa-lg bg-success text-white"style="height:50px;width:50px;border-radius:50%;padding-left:15px;
padding-top:18px; "></i></a>
<a href="https://www.instagram.com/codeslover"><i class="fa fa-instagram fa-lg text-white"style="height:50px;width:50px;border-radius:50%;padding-left:15px;
padding-top:18px; background-color:#1232f; "></i></a>
</div>

<div class="col-sm-2 bg-dark">
<h5 class="text-secondary  my-3">Contact Us</h5>
<p class="text-secondary">Address :<br> RajNagar Extension, Ghaziabad</p>

<p class="text-secondary">Toll Free:<br>1800-255-3030</p>
<p class="text-secondary">Email Us:<br>engineeringofficial@gmail.com</p>
</div>
<div class="col-sm-1 bg-dark"></div>
</div>
<div class="row " style="background-color:#0f787b;">
<div class="col-sm-12 my-1 p-0">
<h6 class="text-white text-center">&copy; <a href="AdminLogIn.php" class="text-white">designed by codeslover </a></h6>
</div>
</div>
</div>
</body>
</html>