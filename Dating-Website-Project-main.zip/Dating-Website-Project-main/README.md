# Dating-Website-Project
Dating Website (Date Mate) is a dating website which helps to date anyone across the world.
I have created this using php and for database I used SQL.
